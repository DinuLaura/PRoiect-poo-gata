﻿﻿using System;

namespace PRoiect_poo_nou;

class Program
{
    static Aplicatie app = new Aplicatie();
    static Utilizator? currentUser = null;

    static void Main(string[] args)
    {
        // Salvează datele la închiderea aplicației
        AppDomain.CurrentDomain.ProcessExit += (sender, eventArgs) =>
        {
            Console.WriteLine("\n⏳ Salvare date la închidere...");
            app.SalveazaDate();
            Console.WriteLine("👋 La revedere!");
        };

        // Gestionează Ctrl+C
        Console.CancelKeyPress += (sender, e) =>
        {
            Console.WriteLine("\n⏳ Salvare date...");
            app.SalveazaDate();
            Console.WriteLine("👋 La revedere!");
            Environment.Exit(0);
        };

        Console.WriteLine("=== SISTEM HOTEL SELF CHECK-IN ===");
        Console.WriteLine("Folosește Ctrl+C pentru a ieși elegant\n");
        
        try
        {
            while (true)
            {
                if (currentUser == null)
                    MeniuPrincipal();
                else if (currentUser is Administrator admin)
                    MeniuAdmin(admin);
                else if (currentUser is Client client)
                    MeniuClient(client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"\n✗ Eroare neașteptată: {ex.Message}");
            Console.WriteLine("Apasă orice tastă pentru a închide...");
            Console.ReadKey();
        }
    }

    static void MeniuPrincipal()
    {
        Console.WriteLine("\n--- MENIU PRINCIPAL ---");
        Console.WriteLine("1. Login");
        Console.WriteLine("2. Înregistrare client");
        Console.WriteLine("3. Exit");
        Console.Write("Alege opțiunea: ");
        
        string opt = Console.ReadLine()?.Trim() ?? "";
        
        switch (opt)
        {
            case "1": Login(); break;
            case "2": InregistrareClient(); break;
            case "3": 
                Console.WriteLine("👋 La revedere!");
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("✗ Opțiune invalidă!");
                break;
        }
    }

    static void Login()
    {
        try
        {
            Console.Write("\n👤 Nume utilizator: ");
            string user = Console.ReadLine()?.Trim() ?? "";
            Console.Write("🔑 Parola: ");
            string pass = Console.ReadLine()?.Trim() ?? "";
            
            currentUser = app.verificare_utilizator(user, pass);
            if (currentUser != null)
            {
                Console.WriteLine($"\n✅ Bun venit, {user}!");
                if (currentUser is Administrator)
                    Console.WriteLine("👑 Modul: Administrator");
                else
                    Console.WriteLine("👤 Modul: Client");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare la login: {ex.Message}");
        }
    }

    static void InregistrareClient()
    {
        try
        {
            Console.WriteLine("\n--- ÎNREGISTRARE CLIENT ---");
            Console.Write("👤 Nume utilizator: ");
            string user = Console.ReadLine()?.Trim() ?? "";
            
            if (string.IsNullOrWhiteSpace(user))
            {
                Console.WriteLine("✗ Numele nu poate fi gol!");
                return;
            }
            
            Console.Write("🔑 Parola: ");
            string pass = Console.ReadLine()?.Trim() ?? "";
            
            if (string.IsNullOrWhiteSpace(pass))
            {
                Console.WriteLine("✗ Parola nu poate fi goală!");
                return;
            }
            
            app.creare_utilizator(user, pass, false);
            Console.WriteLine($"\n✅ Cont creat cu succes! Autentifică-te acum.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ {ex.Message}");
        }
    }

    static void MeniuAdmin(Administrator admin)
    {
        Console.WriteLine("\n--- MENIU ADMINISTRATOR ---");
        Console.WriteLine("1. ➕ Adaugă cameră");
        Console.WriteLine("2. ❌ Șterge cameră");
        Console.WriteLine("3. 📋 Vezi camere");
        Console.WriteLine("4. 🔄 Schimbă status cameră");
        Console.WriteLine("5. ⏰ Setează intervale ore");
        Console.WriteLine("6. 📊 Vezi rezervări active");
        Console.WriteLine("7. 📋 Vezi toate rezervările");
        Console.WriteLine("8. 👥 Gestionează utilizatori");
        Console.WriteLine("9. 🚪 Logout");
        Console.Write("Alege opțiunea: ");
        
        string opt = Console.ReadLine()?.Trim() ?? "";
        
        switch (opt)
        {
            case "1": AdaugaCamera(admin); break;
            case "2": StergeCamera(admin); break;
            case "3": VeziCamere(admin); break;
            case "4": SchimbaStatusCamera(admin); break;
            case "5": SeteazaIntervaleOre(admin); break;
            case "6": admin.Hotel.Vizualizare_Rezervari_Active(); break;
            case "7": admin.Hotel.Vizualizare_Rezervari(); break;
            case "8": GestioneazaUtilizatori(); break;
            case "9": 
                currentUser = null; 
                Console.WriteLine("✅ Delogat cu succes!");
                break;
            default:
                Console.WriteLine("✗ Opțiune invalidă!");
                break;
        }
    }

    static void AdaugaCamera(Administrator admin)
    {
        try
        {
            Console.WriteLine("\n--- ADAUGARE CAMERĂ ---");
            Console.WriteLine("Tip cameră:");
            Console.WriteLine("1. 🛏️  SINGLE");
            Console.WriteLine("2. 🛏️🛏️ DOUBLE");
            Console.WriteLine("3. 👥 GRUP");
            Console.Write("Alege tipul: ");
            
            Camera.Tip_Camera tip;
            switch (Console.ReadLine()?.Trim())
            {
                case "1": tip = Camera.Tip_Camera.CAMERA_SINGLE; break;
                case "2": tip = Camera.Tip_Camera.CAMERA_DOUBLE; break;
                case "3": tip = Camera.Tip_Camera.CAMERA_GRUP; break;
                default:
                    Console.WriteLine("✗ Tip invalid!");
                    return;
            }
            
            Console.WriteLine("\nFacilități (separate prin virgulă):");
            Console.WriteLine("1. 🛁 JACUZZI");
            Console.WriteLine("2. 🎲 BOARDGAMES");
            Console.WriteLine("3. 🍳 BUCĂTĂRIE");
            Console.WriteLine("4. 🐰 MIFFY");
            Console.Write("Alege facilitățile (ex: 1,3): ");
            
            List<Camera.Facilitati> facs = new();
            string? input = Console.ReadLine()?.Trim();
            if (!string.IsNullOrWhiteSpace(input))
            {
                string[] alegeri = input.Split(',');
                foreach (string a in alegeri)
                {
                    switch (a.Trim())
                    {
                        case "1": facs.Add(Camera.Facilitati.JACUZZI); break;
                        case "2": facs.Add(Camera.Facilitati.BOAREDGAMES); break;
                        case "3": facs.Add(Camera.Facilitati.BUCATARIE); break;
                        case "4": facs.Add(Camera.Facilitati.MIFFY); break;
                    }
                }
            }
            
            admin.CreareCamera(tip, facs);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void StergeCamera(Administrator admin)
    {
        try
        {
            Console.Write("\n🔢 Număr cameră de șters: ");
            if (int.TryParse(Console.ReadLine(), out int nr))
            {
                admin.StergereCamera(nr);
            }
            else
            {
                Console.WriteLine("✗ Număr invalid!");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void VeziCamere(Administrator admin)
    {
        Console.WriteLine("\n--- LISTA CAMERE ---");
        if (!admin.Hotel.lista_camere.Any())
        {
            Console.WriteLine("Nu există camere.");
            return;
        }
        
        foreach (var c in admin.Hotel.lista_camere)
        {
            string statusIcon = c.Status switch
            {
                Camera.Status_camera.LIBERA => "🟢",
                Camera.Status_camera.OCUPAT => "🔴",
                Camera.Status_camera.IN_CURATENIE => "🟡",
                Camera.Status_camera.INDISPONIBILA => "⚫",
                _ => "❓"
            };
            
            Console.WriteLine($"{statusIcon} Camera {c.Nr_camera}: {c.Tip} - {c.Status}");
        }
    }

    static void SchimbaStatusCamera(Administrator admin)
    {
        try
        {
            Console.Write("\n🔢 Număr cameră: ");
            if (!int.TryParse(Console.ReadLine(), out int nr))
            {
                Console.WriteLine("✗ Număr invalid!");
                return;
            }
            
            Console.WriteLine("\nStatus nou:");
            Console.WriteLine("1. 🟢 LIBERĂ");
            Console.WriteLine("2. 🔴 OCUPATĂ");
            Console.WriteLine("3. 🟡 ÎN CURĂȚENIE");
            Console.WriteLine("4. ⚫ INDISPONIBILĂ");
            Console.Write("Alege statusul: ");
            
            Camera.Status_camera status;
            switch (Console.ReadLine()?.Trim())
            {
                case "1": status = Camera.Status_camera.LIBERA; break;
                case "2": status = Camera.Status_camera.OCUPAT; break;
                case "3": status = Camera.Status_camera.IN_CURATENIE; break;
                case "4": status = Camera.Status_camera.INDISPONIBILA; break;
                default:
                    Console.WriteLine("✗ Status invalid!");
                    return;
            }
            
            admin.SchimbaStatusCamera(nr, status);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void SeteazaIntervaleOre(Administrator admin)
    {
        try
        {
            Console.WriteLine("\n--- SETARE INTERVALE ORE ---");
            
            Console.Write("⏰ Ora start check-in (HH:mm): ");
            if (!TimeOnly.TryParse(Console.ReadLine(), out TimeOnly oraStart))
            {
                Console.WriteLine("✗ Ora invalidă!");
                return;
            }
            
            Console.Write("⏰ Ora stop check-in (HH:mm): ");
            if (!TimeOnly.TryParse(Console.ReadLine(), out TimeOnly oraStop))
            {
                Console.WriteLine("✗ Ora invalidă!");
                return;
            }
            
            Console.Write("⏰ Ora checkout (HH:mm): ");
            if (!TimeOnly.TryParse(Console.ReadLine(), out TimeOnly oraCheckout))
            {
                Console.WriteLine("✗ Ora invalidă!");
                return;
            }
            
            admin.SetareIntervaleOre(oraStart, oraStop, oraCheckout);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void GestioneazaUtilizatori()
    {
        Console.WriteLine("\n--- GESTIUNE UTILIZATORI ---");
        Console.WriteLine("1. ➕ Crează utilizator nou");
        Console.WriteLine("2. ↩️ Înapoi");
        Console.Write("Alege opțiunea: ");
        
        switch (Console.ReadLine()?.Trim())
        {
            case "1": CreazaUtilizator(); break;
            case "2": break;
            default: Console.WriteLine("✗ Opțiune invalidă!"); break;
        }
    }

    static void CreazaUtilizator()
    {
        try
        {
            Console.Write("\n👤 Nume utilizator: ");
            string user = Console.ReadLine()?.Trim() ?? "";
            
            if (string.IsNullOrWhiteSpace(user))
            {
                Console.WriteLine("✗ Numele nu poate fi gol!");
                return;
            }
            
            Console.Write("🔑 Parola: ");
            string pass = Console.ReadLine()?.Trim() ?? "";
            
            if (string.IsNullOrWhiteSpace(pass))
            {
                Console.WriteLine("✗ Parola nu poate fi goală!");
                return;
            }
            
            Console.Write("👑 Este administrator? (da/nu): ");
            bool isAdmin = Console.ReadLine()?.Trim().ToLower() == "da";
            
            app.creare_utilizator(user, pass, isAdmin);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ {ex.Message}");
        }
    }

    static void MeniuClient(Client client)
    {
        Console.WriteLine("\n--- MENIU CLIENT ---");
        Console.WriteLine("1. 🔍 Caută camere");
        Console.WriteLine("2. 📅 Rezervă cameră");
        Console.WriteLine("3. 📋 Vezi rezervările mele");
        Console.WriteLine("4. ❌ Anulează rezervare");
        Console.WriteLine("5. 🚪 Logout");
        Console.Write("Alege opțiunea: ");
        
        string opt = Console.ReadLine()?.Trim() ?? "";
        
        switch (opt)
        {
            case "1": CautaCamere(); break;
            case "2": RezervaCamera(client); break;
            case "3": app.Hotel.afisare_rezervari(client.Nume); break;
            case "4": AnuleazaRezervare(); break;
            case "5": 
                currentUser = null; 
                Console.WriteLine("✅ Delogat cu succes!");
                break;
            default:
                Console.WriteLine("✗ Opțiune invalidă!");
                break;
        }
    }

    static void CautaCamere()
    {
        try
        {
            Console.WriteLine("\n--- CĂUTARE CAMERE ---");
            
            Console.Write("📅 Data început (dd/mm/aaaa): ");
            if (!DateOnly.TryParse(Console.ReadLine(), out DateOnly start))
            {
                Console.WriteLine("Dată invalidă!");
                return;
            }
            
            Console.Write("📅 Data sfârșit (dd/mm/aaaa): ");
            if (!DateOnly.TryParse(Console.ReadLine(), out DateOnly end))
            {
                Console.WriteLine("Dată invalidă!");
                return;
            }
            
            if (end < start)
            {
                Console.WriteLine("✗ Data de sfârșit trebuie să fie după data de început!");
                return;
            }
            
            Console.WriteLine("\nTip cameră:");
            Console.WriteLine("1. 🛏️  SINGLE");
            Console.WriteLine("2. 🛏️🛏️ DOUBLE");
            Console.WriteLine("3. 👥 GRUP");
            Console.Write("Alege tipul: ");
            
            Camera.Tip_Camera tip;
            switch (Console.ReadLine()?.Trim())
            {
                case "1": tip = Camera.Tip_Camera.CAMERA_SINGLE; break;
                case "2": tip = Camera.Tip_Camera.CAMERA_DOUBLE; break;
                case "3": tip = Camera.Tip_Camera.CAMERA_GRUP; break;
                default:
                    Console.WriteLine("✗ Tip invalid!");
                    return;
            }
            
            var camere = app.Hotel.cauta_camere(start, end, tip, new List<Camera.Facilitati>());
            
            Console.WriteLine($"\n🔍 Găsite {camere.Count} camere disponibile:");
            if (camere.Any())
            {
                foreach (var c in camere)
                {
                    Console.WriteLine($"   🏨 Camera {c.Nr_camera} - {c.Tip} - Facilități: {string.Join(", ", c.Facilitati_cam)}");
                }
            }
            else
            {
                Console.WriteLine("😔 Nu există camere disponibile pentru criteriile selectate.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void RezervaCamera(Client client)
    {
        try
        {
            Console.WriteLine("\n--- REZERVARE CAMERĂ ---");
            
            Console.Write("🔢 Număr cameră: ");
            if (!int.TryParse(Console.ReadLine(), out int nr))
            {
                Console.WriteLine("✗ Număr invalid!");
                return;
            }
            
            Console.Write("📅 Data început (dd/mm/aaaa): ");
            if (!DateOnly.TryParse(Console.ReadLine(), out DateOnly start))
            {
                Console.WriteLine("✗ Dată invalidă!");
                return;
            }
            
            Console.Write("📅 Data sfârșit (dd/mm/aaaa): ");
            if (!DateOnly.TryParse(Console.ReadLine(), out DateOnly end))
            {
                Console.WriteLine("✗ Dată invalidă!");
                return;
            }
            
            if (end < start)
            {
                Console.WriteLine("✗ Data de sfârșit trebuie să fie după data de început!");
                return;
            }
            
            app.Hotel.rezervare_camera(client.Nume, start, end, nr);
            app.SalveazaDate();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }

    static void AnuleazaRezervare()
    {
        try
        {
            Console.Write("\nID rezervare de anulat: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                app.Hotel.anulare_rezervare(id);
                app.SalveazaDate();
            }
            else
            {
                Console.WriteLine("✗ ID invalid!");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
        }
    }
}