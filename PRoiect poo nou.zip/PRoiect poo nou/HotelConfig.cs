﻿namespace PRoiect_poo_nou;

public class HotelConfig
{
    public TimeOnly ora_start_checkin { get; set; }
    public TimeOnly ora_stop_checkin { get; set; }
    public TimeOnly ora_checkout { get; set; }

    public HotelConfig()
    {
        ora_start_checkin = new TimeOnly(12, 0);
        ora_stop_checkin = new TimeOnly(20, 0);
        ora_checkout = new TimeOnly(12, 0);
    }

    public HotelConfig(TimeOnly start, TimeOnly stop, TimeOnly checkout)
    {
        ora_start_checkin = start;
        ora_stop_checkin = stop;
        ora_checkout = checkout;
    }
}