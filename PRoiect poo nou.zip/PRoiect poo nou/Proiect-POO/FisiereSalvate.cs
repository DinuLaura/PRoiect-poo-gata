﻿namespace PRoiect_poo_nou;

using System.Text.Json;
using System.Text.Json.Serialization;

public class FisiereSalvate
{
    private const string CamereFile = "camere.json";
    private const string RezervariFile = "rezervari.json";
    private const string UtilizatoriFile = "utilizatori.json";
    private const string HotelConfigFile = "hotel_config.json";

    // Clase pentru serializare
    private class CameraData
    {
        public int NrCamera { get; set; }
        public Camera.Tip_Camera Tip { get; set; }
        public Camera.Status_camera Status { get; set; }
        public List<Camera.Facilitati> Facilitati { get; set; } = new();
    }

    private class RezervareData
    {
        public int Id { get; set; }
        public string NumeClient { get; set; } = "";
        public int NrCamera { get; set; }
        public DateOnly Inceput { get; set; }
        public DateOnly Sfarsit { get; set; }
        public bool Activa { get; set; }
        public Rezervari.Status_rezervare Status { get; set; }
    }

    private class UserData
    {
        public string Nume { get; set; } = "";
        public string Parola { get; set; } = "";
        public bool IsAdmin { get; set; }
    }

    public (List<Camera> camere, List<Rezervari> rezervari, List<Utilizator> utilizatori, HotelConfig config) IncarcaDate()
    {
        List<Camera> camere = new();
        List<Rezervari> rezervari = new();
        List<Utilizator> utilizatori = new();
        HotelConfig config = new HotelConfig();

        try
        {
            // Încarcă configurația hotelului
            if (File.Exists(HotelConfigFile))
            {
                try
                {
                    string jsonConfig = File.ReadAllText(HotelConfigFile);
                    config = JsonSerializer.Deserialize<HotelConfig>(jsonConfig) ?? new HotelConfig();
                }
                catch (JsonException)
                {
                    Console.WriteLine("⚠ Configurație invalidă, folosesc valori default");
                    config = new HotelConfig();
                }
            }

            // Încarcă camerele
            if (File.Exists(CamereFile))
            {
                try
                {
                    string jsonCamere = File.ReadAllText(CamereFile);
                    if (!string.IsNullOrWhiteSpace(jsonCamere))
                    {
                        var camereData = JsonSerializer.Deserialize<List<CameraData>>(jsonCamere);
                        if (camereData != null)
                        {
                            foreach (var camData in camereData)
                            {
                                var camera = new Camera(camData.NrCamera, camData.Tip, camData.Facilitati)
                                {
                                    Status = camData.Status
                                };
                                camere.Add(camera);
                            }
                        }
                    }
                }
                catch (JsonException ex)
                {
                    Console.WriteLine($"⚠ Eroare la încărcarea camerelor: {ex.Message}");
                    // Continuăm cu liste goale
                }
            }

            // Încarcă rezervările
            if (File.Exists(RezervariFile))
            {
                try
                {
                    string jsonRezervari = File.ReadAllText(RezervariFile);
                    if (!string.IsNullOrWhiteSpace(jsonRezervari))
                    {
                        var rezervariData = JsonSerializer.Deserialize<List<RezervareData>>(jsonRezervari);
                        if (rezervariData != null)
                        {
                            // Trebuie să avem camerele încărcate mai întâi
                            foreach (var rezData in rezervariData)
                            {
                                var camera = camere.FirstOrDefault(c => c.Nr_camera == rezData.NrCamera);
                                if (camera != null)
                                {
                                    var rezervare = new Rezervari(
                                        rezData.NumeClient, 
                                        camera, 
                                        rezData.Inceput, 
                                        rezData.Sfarsit, 
                                        rezData.Id);
                                    
                                    if (rezData.Status == Rezervari.Status_rezervare.REZERVARE_ANULATA)
                                    {
                                        rezervare.Schimb_Status(Rezervari.Status_rezervare.REZERVARE_ANULATA);
                                    }
                                    
                                    rezervari.Add(rezervare);
                                }
                            }
                        }
                    }
                }
                catch (JsonException ex)
                {
                    Console.WriteLine($"⚠ Eroare la încărcarea rezervărilor: {ex.Message}");
                }
            }

            // Încarcă utilizatorii
            if (File.Exists(UtilizatoriFile))
            {
                try
                {
                    string jsonUtilizatori = File.ReadAllText(UtilizatoriFile);
                    if (!string.IsNullOrWhiteSpace(jsonUtilizatori))
                    {
                        var userDataList = JsonSerializer.Deserialize<List<UserData>>(jsonUtilizatori);
                        if (userDataList != null)
                        {
                            foreach (var userData in userDataList)
                            {
                                // Adminii vor fi recreați mai târziu în Aplicatie
                                if (userData.IsAdmin)
                                {
                                    // Creăm un client temporar
                                    utilizatori.Add(new Client(userData.Nume, userData.Parola));
                                }
                                else
                                {
                                    utilizatori.Add(new Client(userData.Nume, userData.Parola));
                                }
                            }
                        }
                    }
                }
                catch (JsonException ex)
                {
                    Console.WriteLine($"⚠ Eroare la încărcarea utilizatorilor: {ex.Message}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare neașteptată la încărcarea datelor: {ex.Message}");
        }

        return (camere, rezervari, utilizatori, config);
    }

    public void SalveazaDate(Hotel hotel, List<Utilizator> utilizatori)
    {
        try
        {
            // Salvează configurația
            var config = new HotelConfig(
                hotel.ora_start_checkin,
                hotel.ora_stop_checkin,
                hotel.ora_checkout);
            
            string jsonConfig = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(HotelConfigFile, jsonConfig);

            // Salvează camerele
            var camereData = hotel.lista_camere.Select(c => new CameraData
            {
                NrCamera = c.Nr_camera,
                Tip = c.Tip,
                Status = c.Status,
                Facilitati = c.Facilitati_cam
            }).ToList();
            
            string jsonCamere = JsonSerializer.Serialize(camereData, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(CamereFile, jsonCamere);

            // Salvează rezervările
            var rezervariData = hotel.lista_rezarvari.Select(r => new RezervareData
            {
                Id = r.id,
                NumeClient = r.Nume_client,
                NrCamera = r.Camera.Nr_camera,
                Inceput = r.Inceput_rezervare,
                Sfarsit = r.Sfarsit_rezervare,
                Activa = r.activa,
                Status = r.Status
            }).ToList();
            
            string jsonRezervari = JsonSerializer.Serialize(rezervariData, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(RezervariFile, jsonRezervari);

            // Salvează utilizatorii
            var userDataList = utilizatori.Select(u => new UserData
            {
                Nume = u.Nume,
                Parola = u.Parola,
                IsAdmin = u is Administrator
            }).ToList();
            
            string jsonUtilizatori = JsonSerializer.Serialize(userDataList, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(UtilizatoriFile, jsonUtilizatori);

            Console.WriteLine("✓ Date salvate cu succes!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare la salvarea datelor: {ex.Message}");
        }
    }
}