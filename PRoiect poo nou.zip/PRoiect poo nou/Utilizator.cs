﻿namespace PRoiect_poo_nou;

public abstract class Utilizator
{
    public string Nume { get; protected set; } = "";
    public string Parola { get; protected set; } = "";
}