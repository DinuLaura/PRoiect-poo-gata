﻿namespace PRoiect_poo_nou;

public class Client : Utilizator
{
    public Client(string nume, string parola)
    {
        Nume = nume ?? throw new ArgumentNullException(nameof(nume));
        Parola = parola ?? throw new ArgumentNullException(nameof(parola));
    }
}