﻿namespace PRoiect_poo_nou;

public class Hotel
{
    public TimeOnly ora_start_checkin { get; private set; }
    public TimeOnly ora_stop_checkin { get; private set; }
    public TimeOnly ora_checkout { get; private set; }
    public List<Camera> lista_camere { get; set; }
    private int cnt = 0;
    private int cnt_rezervari = 0;
    public List<Rezervari> lista_rezarvari { get; set; }

    public Hotel(List<Camera>? camere = null, List<Rezervari>? rezervari = null, HotelConfig? config = null)
    {
        lista_camere = camere ?? new List<Camera>();
        lista_rezarvari = rezervari ?? new List<Rezervari>();
    
        // Determină următoarele ID-uri
        if (lista_camere.Any())
            cnt = lista_camere.Max(c => c.Nr_camera) + 1;
        
        if (lista_rezarvari.Any())
            cnt_rezervari = lista_rezarvari.Max(r => r.id) + 1;
    
        // Setează orele default sau din config
        if (config != null)
        {
            ora_start_checkin = config.ora_start_checkin;
            ora_stop_checkin = config.ora_stop_checkin;
            ora_checkout = config.ora_checkout;
        }
        else
        {
            ora_start_checkin = new TimeOnly(12, 0);
            ora_stop_checkin = new TimeOnly(20, 0);
            ora_checkout = new TimeOnly(12, 0);
        }
    }
    public void Adaugare_camera(Camera.Tip_Camera tip, List<Camera.Facilitati> facilitati)
    {
        try
        {
            Camera camera_noua = new Camera(cnt++, tip, facilitati ?? new List<Camera.Facilitati>());
            lista_camere.Add(camera_noua);
            Console.WriteLine($"✓ Camera {camera_noua.Nr_camera} adăugată cu succes!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare la adăugarea camerei: {ex.Message}");
            throw;
        }
    }

    public void Stergere_camera(int Nrcameraid)
    {
        try
        {
            var camera = lista_camere.FirstOrDefault(c => c.Nr_camera == Nrcameraid);
            if (camera != null)
            {
                // Verifică dacă camera are rezervări active
                bool areRezervariActive = lista_rezarvari.Any(r => 
                    r.Camera.Nr_camera == Nrcameraid && r.activa);
                
                if (areRezervariActive)
                {
                    throw new InvalidOperationException(
                        $"Camera {Nrcameraid} are rezervări active. Anulați rezervările înainte de ștergere.");
                }
                
                lista_camere.Remove(camera);
                // Șterge și rezervările pentru această cameră
                lista_rezarvari.RemoveAll(r => r.Camera.Nr_camera == Nrcameraid);
            }
            else
            {
                throw new ArgumentException($"Camera cu numărul {Nrcameraid} nu există!");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ Eroare: {ex.Message}");
            throw;
        }
    }

    public Camera GetCamera(int NrCameraid)
    {
        foreach (var cam in lista_camere)
        {
            if (cam.Nr_camera == NrCameraid)
                return cam;
        }
        throw new KeyNotFoundException($"Camera cu numărul {NrCameraid} nu a fost găsită!");
    }
    
    public void Adaugare_rezervari(Rezervari rezervare)
    {
        if (rezervare == null)
            throw new ArgumentNullException(nameof(rezervare));
            
        lista_rezarvari.Add(rezervare);
    }

    public void Vizualizare_Rezervari()
    {
        if (!lista_rezarvari.Any())
        {
            Console.WriteLine("Nu există rezervări.");
            return;
        }
        
        Vizualizare_Rezervari_List(lista_rezarvari);
    }

    public void Vizualizare_Rezervari_Active()
    {
        List<Rezervari> rezervari_active = new List<Rezervari>();
        foreach (var rezervare in lista_rezarvari)
        {
            if (rezervare.activa)
                rezervari_active.Add(rezervare);
        }
        
        if (!rezervari_active.Any())
        {
            Console.WriteLine("Nu există rezervări active.");
            return;
        }
        
        Vizualizare_Rezervari_List(rezervari_active);
    }

    private void Vizualizare_Rezervari_List(List<Rezervari> rezervari)
    {
        Console.WriteLine($"\n--- REZERVĂRI ({rezervari.Count}) ---");
        int counter = 1;
        foreach (var rezervare in rezervari)
        {
            Console.WriteLine($"{counter++}. {rezervare}");
        }
    }

    public void setare_ore(TimeOnly in_cek, TimeOnly out_cek, TimeOnly cekout)
    {
        if (out_cek <= in_cek)
            throw new ArgumentException("Ora de stop check-in trebuie să fie după ora de start");
            
        ora_start_checkin = in_cek;
        ora_stop_checkin = out_cek;
        ora_checkout = cekout;
        Console.WriteLine($"✓ Ore setate: Check-in {in_cek}-{out_cek}, Check-out {cekout}");
    }

    public List<Camera> cauta_camere(DateOnly start_perioada, DateOnly sfarsit_perioada, 
        Camera.Tip_Camera tip, List<Camera.Facilitati> facilitati)
    {
        if (sfarsit_perioada < start_perioada)
            throw new ArgumentException("Data de sfârșit trebuie să fie după data de început");
            
        List<Camera> camere_gasite = new List<Camera>();
        
        foreach(Camera camera in lista_camere)
        {
            // Verifică tipul
            if (!camera.Tip.Equals(tip))
                continue;

            // Verifică facilitățile
            bool facilitati_indeplinite = true;
            if (facilitati != null)
            {
                foreach (Camera.Facilitati facilitate in facilitati)
                {
                    if (!camera.Facilitati_cam.Contains(facilitate))
                    {
                        facilitati_indeplinite = false;
                        break;
                    }
                }
            }

            if (!facilitati_indeplinite)
                continue;

            // Verifică disponibilitatea
            if (intercalare_rezervari(camera, start_perioada, sfarsit_perioada))
                continue;
            
            // Verifică statusul camerei
            if (camera.Status != Camera.Status_camera.LIBERA)
                continue;
            
            camere_gasite.Add(camera);
        }
        
        return camere_gasite;
    }

    private bool intercalare_rezervari(Camera camera, DateOnly start_perioada, DateOnly sfarsit_perioada)
    {
        foreach (Rezervari rezervare in lista_rezarvari)
        {
            if (rezervare.Camera.Nr_camera == camera.Nr_camera && rezervare.activa)
            {
                if (rezervare.Inceput_rezervare <= sfarsit_perioada && 
                    rezervare.Sfarsit_rezervare >= start_perioada)
                    return true;
            }
        }
        return false;
    }

    private Camera camera_dupa_id(int id)
    {
        foreach (Camera camera in lista_camere)
        {
            if (camera.Nr_camera == id)
                return camera;
        }
        return null;
    }
    
    public void rezervare_camera(string nume, DateOnly start_rez, DateOnly stop_rez, int nr_cam)
    {
        try
        {
            Camera cam_rez = camera_dupa_id(nr_cam);
            if (cam_rez == null)
            {
                throw new ArgumentException($"Camera {nr_cam} nu există!");
            }
            
            if (stop_rez < start_rez)
            {
                throw new ArgumentException("Data de sfârșit trebuie să fie după data de început!");
            }
            
            if (intercalare_rezervari(cam_rez, start_rez, stop_rez))
            {
                throw new InvalidOperationException(
                    $"Camera {nr_cam} este indisponibilă în perioada {start_rez} - {stop_rez}!");
            }

            Rezervari rezervare = new Rezervari(nume, cam_rez, start_rez, stop_rez, cnt_rezervari++);
            lista_rezarvari.Add(rezervare);
            Console.WriteLine($"✓ Rezervare #{rezervare.id} creată cu succes!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"✗ {ex.Message}");
            throw;
        }
    }
    
    public void afisare_rezervari(string nume)
    {
        if (string.IsNullOrWhiteSpace(nume))
            throw new ArgumentException("Numele este obligatoriu");
            
        Console.WriteLine($"\n--- REZERVĂRI PENTRU {nume} ---");
        bool gasite = false;
        
        foreach (Rezervari rez in lista_rezarvari)
        {
            if (rez.Nume_client == nume)
            {
                Console.WriteLine($"ID: {rez.id}, Camera: {rez.Camera.Nr_camera}, " +
                    $"Perioada: {rez.Inceput_rezervare} → {rez.Sfarsit_rezervare}, " +
                    $"Status: {rez.Status} {(rez.activa ? "(activă)" : "(anulată)")}");
                gasite = true;
            }
        }
        
        if (!gasite)
            Console.WriteLine("Nu aveți rezervări.");
    }
    
    public void anulare_rezervare(int id)
    {
        var rezervare = lista_rezarvari.FirstOrDefault(r => r.id == id);
        if (rezervare != null)
        {
            if (!rezervare.activa)
            {
                Console.WriteLine("Această rezervare este deja anulată.");
                return;
            }
            
            rezervare.Schimb_Status(Rezervari.Status_rezervare.REZERVARE_ANULATA);
            Console.WriteLine($"✓ Rezervarea #{id} a fost anulată!");
        }
        else
        {
            throw new ArgumentException($"Rezervarea cu ID-ul {id} nu există!");
        }
    }
    
    public void modificare_rezervare(Rezervari rezervare, DateOnly new_start_date, DateOnly new_end_date)
    {
        if (rezervare == null)
            throw new ArgumentNullException(nameof(rezervare));
            
        if (new_end_date < new_start_date)
            throw new ArgumentException("Data de sfârșit trebuie să fie după data de început");
            
        if (!rezervare.activa)
            throw new InvalidOperationException("Nu se poate modifica o rezervare anulată");
            
        if (intercalare_rezervari(rezervare.Camera, new_start_date, new_end_date))
        {
            throw new InvalidOperationException(
                "Camera este indisponibilă pentru noua perioadă!");
        }
        
        rezervare.setare_inceput_rezervare(new_start_date);
        rezervare.setare_sfarsit_rezervare(new_end_date);
        Console.WriteLine($"✓ Rezervarea #{rezervare.id} a fost modificată!");
    }
}